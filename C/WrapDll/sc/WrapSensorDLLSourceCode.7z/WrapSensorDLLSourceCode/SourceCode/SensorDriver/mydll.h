// setting struct byte align method
#pragma	pack(push, 1)

// defined DSA
typedef struct {
    unsigned char Sign; 			// Sign +/-
    unsigned char Integer[3]; 		// 3-digit integer(no zero suppression)
    unsigned char Period;			// Decimal point(".")
    unsigned char Decimal[6];		// 6-digit decimal number
} Number;

typedef struct {
	unsigned long TopPoint;				// such as 1
	unsigned long EndPoint;				// such as 400
	unsigned short dwCount;				// such as 500
	
	// such as -123.123456
	Number* pValue;
} NormalBuffer;

// export a dll
_declspec(dllexport) void GetBufferDataNormal(NormalBuffer* pNormalBuffer);


#pragma	pack(pop)