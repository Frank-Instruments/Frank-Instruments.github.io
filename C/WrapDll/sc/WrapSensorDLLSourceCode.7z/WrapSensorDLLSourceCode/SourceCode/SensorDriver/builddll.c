#include "mydll.h"

// function defined
// Cause we are only care about the NormalBuffer ptr, so we just write a function
// it make *pBuffer every value increase 1;
void
GetBufferDataNormal(NormalBuffer* pBuffer){

// +1
// update the struct member value
pBuffer->TopPoint = pBuffer->TopPoint + 1;
pBuffer->EndPoint = pBuffer->EndPoint + 1;
pBuffer->dwCount = pBuffer->dwCount + 1;

// keep constant neg char
pBuffer->pValue->Sign = '-';


// although the char shoud is 0~9 refer to number, but we only add 1
// indicate the input parameter successfully pass the fucntion
pBuffer->pValue->Integer[0] = pBuffer->pValue->Integer[0] + 1;
pBuffer->pValue->Integer[1] = pBuffer->pValue->Integer[1] + 1;
pBuffer->pValue->Integer[2] = pBuffer->pValue->Integer[2] + 1;

// keep the point char
pBuffer->pValue->Period = '.';

// add + 1
pBuffer->pValue->Decimal[0] = pBuffer->pValue->Decimal[0] + 1;
pBuffer->pValue->Decimal[1] = pBuffer->pValue->Decimal[1] + 1;
pBuffer->pValue->Decimal[2] = pBuffer->pValue->Decimal[2] + 1;
pBuffer->pValue->Decimal[3] = pBuffer->pValue->Decimal[3] + 1;
pBuffer->pValue->Decimal[4] = pBuffer->pValue->Decimal[4] + 1;
pBuffer->pValue->Decimal[5] = pBuffer->pValue->Decimal[5] + 1;

// no return
}