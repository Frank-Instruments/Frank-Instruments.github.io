#include "wrapperdll.h"

// define wrapper function
void GetBufferDataNormalWrapperDll(Data* pData)
{
	// new strct vars from deriver
	Number Number;
	NormalBuffer NormalBufferV;
	
	// new function ptr
	DLLFUNC pGetBufferDataNormal;


	// load dll, get dll file handle
	// using relative path, just place myDll.dll file same path
	// with this wrapperdll.dll
	HINSTANCE DllHandle = LoadLibrary(L".\\myDll.dll");
	
	// only for debug
	// if get any error, using GetLastError() get the error code
	/*
	unsigned long error_id;
	error_id = GetLastError();
	pData->TopPoint = error_id;
	*/

	// init the pointer element with input parameter
	// init NumberV struct
	Number.Sign = pData->Sign;
	Number.Integer[0] = pData->Integer0;
	Number.Integer[1] = pData->Integer1;
	Number.Integer[2] = pData->Integer2;
	Number.Period = pData->Period;
	Number.Decimal[0] = pData->Decimal0;
	Number.Decimal[1] = pData->Decimal1;
	Number.Decimal[2] = pData->Decimal2;
	Number.Decimal[3] = pData->Decimal3;
	Number.Decimal[4] = pData->Decimal4;
	Number.Decimal[5] = pData->Decimal5;

	// init the NormalBufferV struct
	NormalBufferV.TopPoint = pData->TopPoint;
	NormalBufferV.EndPoint = pData->EndPoint;
	NormalBufferV.dwCount = pData->dwCount;
	NormalBufferV.pValue = &Number;
	
	if (DllHandle) {
		// pointer is valid
		// init get the function ptr
		pGetBufferDataNormal = (DLLFUNC)GetProcAddress(DllHandle, "GetBufferDataNormal");
		if (pGetBufferDataNormal)
		{
			// pointer valid
			// call the function to change the NormalBufferV struc
			// this function will make normalbufferV head 3 element +1
			// others element get -123.123456
			// pass the parameter to driver dll and call the driver function GetBufferDataNormal
			pGetBufferDataNormal(&NormalBufferV);

			// after call, build return value to output parameter
			pData->TopPoint = NormalBufferV.TopPoint;
			pData->EndPoint = NormalBufferV.EndPoint;
			pData->dwCount = NormalBufferV.dwCount;

			pData->Sign = (NormalBufferV.pValue)->Sign;
			pData->Integer0 = (NormalBufferV.pValue)->Integer[0];
			pData->Integer1 = (NormalBufferV.pValue)->Integer[1];
			pData->Integer2 = (NormalBufferV.pValue)->Integer[2];
			pData->Period = (NormalBufferV.pValue)->Period;
			pData->Decimal0 = (NormalBufferV.pValue)->Decimal[0];
			pData->Decimal1 = (NormalBufferV.pValue)->Decimal[1];
			pData->Decimal2 = (NormalBufferV.pValue)->Decimal[2];
			pData->Decimal3 = (NormalBufferV.pValue)->Decimal[3];
			pData->Decimal4 = (NormalBufferV.pValue)->Decimal[4];
			pData->Decimal5 = (NormalBufferV.pValue)->Decimal[5];

		}
		// free the ptr
		FreeLibrary(DllHandle);
	}
	// no return
}

unsigned long GetDllVersion(void){
	// return a version number
	return 100;
}