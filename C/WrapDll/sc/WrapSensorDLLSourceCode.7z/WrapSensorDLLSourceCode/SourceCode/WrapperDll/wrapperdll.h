#include <Windows.h>

#pragma	pack(push, 1)

// defined DSA
typedef struct {
    unsigned char Sign; 			// Sign +/-
    unsigned char Integer[3]; 		// 3-digit integer(no zero suppression)
    unsigned char Period;			// Decimal point(".")
    unsigned char Decimal[6];		// 6-digit decimal number
} Number;

typedef struct {
	unsigned long TopPoint;				// such as 1
	unsigned long EndPoint;				// such as 400
	unsigned short dwCount;				// such as 500
	
	// such as -123.123456
	Number* pValue;
} NormalBuffer;


// new a sample struct to change the dll complex struct to a sampe struct
// make LV conveniently call
// the new sample stuct will as function input
typedef struct {
	unsigned long TopPoint;
	unsigned long EndPoint;
	unsigned short dwCount;

	// Sign +/-
	unsigned char Sign;

	// 3-digit integer(no zero suppression)
    unsigned char Integer0;
	unsigned char Integer1;
	unsigned char Integer2;

	// Decimal point(".")
    unsigned char Period;

	// 6-digit decimal number
    unsigned char Decimal0;
	unsigned char Decimal1;
	unsigned char Decimal2;
	unsigned char Decimal3;
	unsigned char Decimal4;
	unsigned char Decimal5;

} Data;

#pragma	pack(pop)


// define function pointer
// the interface is be call function parameter
typedef void (*DLLFUNC)(NormalBuffer* pNormalBuffer);


// export dll
_declspec(dllexport) void GetBufferDataNormalWrapperDll(Data* pData);

_declspec(dllexport) unsigned long GetDllVersion(void);